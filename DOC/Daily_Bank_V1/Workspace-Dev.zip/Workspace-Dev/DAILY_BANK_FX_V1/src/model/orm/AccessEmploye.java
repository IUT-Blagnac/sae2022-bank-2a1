package model.orm;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import model.data.Employe;
import model.orm.exception.DataAccessException;
import model.orm.exception.DatabaseConnexionException;
import model.orm.exception.Order;
import model.orm.exception.RowNotFoundOrTooManyRowsException;
import model.orm.exception.Table;

public class AccessEmploye {

	public AccessEmploye() {
	}

	/**
	 * Recherche d'un employe par son login / mot de passe.
	 *
	 * @param login    login de l'employé recherché
	 * @param password mot de passe donné
	 * @return un Employe ou null si non trouvé
	 * @throws RowNotFoundOrTooManyRowsException
	 * @throws DataAccessException
	 * @throws DatabaseConnexionException
	 */
	public Employe getEmploye(String login, String password)
			throws RowNotFoundOrTooManyRowsException, DataAccessException, DatabaseConnexionException {
		Employe employeTrouve;

		try {
			Connection con = LogToDatabase.getConnexion();
			String query = "SELECT * FROM Employe WHERE" + " login = ?" + " AND motPasse = ?";

			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, login);
			pst.setString(2, password);

			ResultSet rs = pst.executeQuery();

			System.err.println(query);

			if (rs.next()) {
				int idEmployeTrouve = rs.getInt("idEmploye");
				String nom = rs.getString("nom");
				String prenom = rs.getString("prenom");
				String droitsAccess = rs.getString("droitsAccess");
				String loginTROUVE = rs.getString("login");
				String motPasseTROUVE = rs.getString("motPasse");
				int idAgEmploye = rs.getInt("idAg");

				employeTrouve = new Employe(idEmployeTrouve, nom, prenom, droitsAccess, loginTROUVE, motPasseTROUVE,
						idAgEmploye);
			} else {
				rs.close();
				pst.close();
				// Non trouvé
				return null;
			}

			if (rs.next()) {
				// Trouvé plus de 1 ... bizarre ...
				rs.close();
				pst.close();
				throw new RowNotFoundOrTooManyRowsException(Table.Employe, Order.SELECT,
						"Recherche anormale (en trouve au moins 2)", null, 2);
			}
			rs.close();
			pst.close();
			return employeTrouve;
		} catch (SQLException e) {
			throw new DataAccessException(Table.Employe, Order.SELECT, "Erreur accès", e);
		}
	}
	
	/**
	 * Récupère la liste des employés dans la base de données correspondant au critères de recherche.
	 * Les critères peuvent être nul. Si ils le sont tous, tout les employés de l'agence correspondant a l'employé connecté sont renvoyé.
	 * 
	 * @param _numEmploye le numéro de l'employé recherché
	 * @param _debutNom Le début du nom de l'employé recherché
	 * @param _debutPrenom Le début du prénom de l'employé recherché
	 * @param _idAg L'id de l'agence de l'employé recherché
	 * @param _idEmployeConnecter L'id de l'employé connecter, pour qu'il ne soit pas prit en compte dans les recherches
	 * @return Une arrayList des employés
	 * @throws DatabaseConnexionException
	 * 
	 * (Antoine MAZEAU)
	 */
	public ArrayList<Employe> getEmployes(int _numEmploye, String _debutNom, String _debutPrenom,int _idAg, Employe _idEmployeConnecter) throws DatabaseConnexionException{
		ArrayList<Employe> alRes = new ArrayList<Employe>();

		try {
			Connection con = LogToDatabase.getConnexion();

			PreparedStatement pst;
			//String query ="SELECT * FROM Employe";
			String query;

			if (_numEmploye != -1) {
				query = "SELECT * FROM Employe where idAg = ?";
				query += " AND idEmploye = ?";
				query += " ORDER BY nom";
				pst = con.prepareStatement(query);
				pst.setInt(1, _idAg);
				pst.setInt(2, _numEmploye);
			} else if (!_debutNom.equals("")) {
				_debutNom = _debutNom.toUpperCase() + "%";
				_debutPrenom = _debutPrenom.toUpperCase() + "%";
				query = "SELECT * FROM Employe where idAg = ?";
				query += " AND UPPER(nom) like ?" + " AND UPPER(prenom) like ?";
				query += " ORDER BY nom";
				pst = con.prepareStatement(query);
				pst.setInt(1, _idAg);
				pst.setString(2, _debutNom);
				pst.setString(3, _debutPrenom);
			} else {
				query = "SELECT * FROM Employe where idAg = ?";
				query += " ORDER BY nom";
				pst = con.prepareStatement(query);
				pst.setInt(1, _idAg);
			}
			System.err.println(query + " nom : " + _debutNom + " prenom : " + _debutPrenom + "#");


			//PreparedStatement pst = con.prepareStatement(query);
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				int idEmploye = rs.getInt("idEmploye");
				if (idEmploye != _idEmployeConnecter.idEmploye) {
					String nom = rs.getString("nom");
					String prenom = rs.getString("prenom");
					String droitsAccess = rs.getString("droitsAccess");
					String login = rs.getString("login");
					String motPasse = rs.getString("motPasse");
					int idAg = rs.getInt("idAg");

					alRes.add(
							new Employe(idEmploye, nom, prenom, droitsAccess, login, motPasse, idAg));

				}
			}
			rs.close();
			pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return alRes;
	}
	
	/**
	 * Insere dans la base de donnée l'employé qui a été crée et est fourni en paramètre
	 * 
	 * @param employe l'employé à insérer
	 * @throws RowNotFoundOrTooManyRowsException
	 * @throws DataAccessException
	 * @throws DatabaseConnexionException
	 * 
	 * (Antoine MAZEAU)
	 */
	public void insertEmploye(Employe employe)
			throws RowNotFoundOrTooManyRowsException, DataAccessException, DatabaseConnexionException {
		try {
			Connection con = LogToDatabase.getConnexion();

			String query = "INSERT INTO EMPLOYE VALUES (" + "seq_id_employe.NEXTVAL" + ", " + "?" + ", " + "?" + ", "
					+ "?" + ", " + "?" + ", " + "?"+ ", " + "?" +")";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, employe.nom);
			pst.setString(2, employe.prenom);
			pst.setString(3, employe.droitsAccess);
			pst.setString(4, employe.login);
			pst.setString(5, employe.motPasse);
			pst.setInt(6, employe.idAg);
			
			System.err.println(query);

			int result = pst.executeUpdate();
			pst.close();
			
			if (result != 1) {
				con.rollback();
				throw new RowNotFoundOrTooManyRowsException(Table.Client, Order.INSERT,
						"Insert anormal (insert de moins ou plus d'une ligne)", null, result);
			}
			
			query = "SELECT seq_id_employe.CURRVAL from DUAL";

			System.err.println(query);
			PreparedStatement pst2 = con.prepareStatement(query);

			ResultSet rs = pst2.executeQuery();
			rs.next();
			int numCliBase = rs.getInt(1);

			con.commit();
			rs.close();
			pst2.close();

			employe.idEmploye = numCliBase;
			
		} catch (SQLException e) {
			throw new DataAccessException(Table.Client, Order.INSERT, "Erreur accÃ¨s", e);
		}
	}
	
	/**
	 * Actualise dans la base de données les modifications effecutés sur l'employé fourni en parametre.
	 * 
	 * @param employe l'employé modifié
	 * @throws RowNotFoundOrTooManyRowsException
	 * @throws DataAccessException
	 * @throws DatabaseConnexionException
	 * 
	 * (Antoine MAZEAU)
	 */
	public void updateEmploye(Employe employe)
			throws RowNotFoundOrTooManyRowsException, DataAccessException, DatabaseConnexionException {
		try {
			Connection con = LogToDatabase.getConnexion();
	
			String query = "UPDATE EMPLOYE SET " + "nom = " + "? , " + "prenom = " + "? , " + "droitsAccess = "
					+ "? , " + "login = " + "? , " + "motPasse = " + "?" +  " "
					+ "WHERE idEmploye = ? ";
	
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, employe.nom);
			pst.setString(2, employe.prenom);
			pst.setString(3, employe.droitsAccess);
			pst.setString(4, employe.login);
			pst.setString(5, employe.motPasse);
			pst.setInt(6, employe.idEmploye);
			
			System.err.println(query);
			

			int result = pst.executeUpdate();
			pst.close();
			if (result != 1) {
				con.rollback();
				throw new RowNotFoundOrTooManyRowsException(Table.Client, Order.UPDATE,
						"Update anormal (update de moins ou plus d'une ligne)", null, result);
			}
			con.commit();
		} catch (SQLException e) {
			throw new DataAccessException(Table.Employe, Order.UPDATE, "Erreur accÃ¨s", e);
		}
	
	}
	
	/**
	 * Supprime de la base de donnée l'employé fourni
	 * 
	 * @param employe L'employé à supprimer
	 * @throws RowNotFoundOrTooManyRowsException
	 * @throws DataAccessException
	 * @throws DatabaseConnexionException
	 * 
	 * (Antoine MAZEAU)
	 */
	public void deleteEmploye(Employe employe)
			throws RowNotFoundOrTooManyRowsException, DataAccessException, DatabaseConnexionException {
		try {
			Connection con = LogToDatabase.getConnexion();
	
			String query = "DELETE FROM EMPLOYE " + "WHERE idEmploye = ? ";
	
			PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, employe.idEmploye);
			
			System.err.println(query);
			pst.executeQuery();
			pst.close();
			
			
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Confirmation");
			alert.setHeaderText("Voulez vous vraiment supprimer "+employe.prenom+" "+employe.nom+" ?");
			
			Optional<ButtonType> result = alert.showAndWait();
			if (result.get() == ButtonType.OK) {
				con.commit();
			} else {
				con.rollback();
			}
		} catch (SQLException e) {
			throw new DataAccessException(Table.Employe, Order.UPDATE, "Erreur accÃ¨s", e);
		}
	
	}
}
