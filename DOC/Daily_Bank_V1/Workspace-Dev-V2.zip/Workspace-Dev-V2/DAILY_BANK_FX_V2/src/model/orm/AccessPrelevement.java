package model.orm;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.data.Prelevement;
import model.orm.exception.DataAccessException;
import model.orm.exception.DatabaseConnexionException;
import model.orm.exception.ManagementRuleViolation;
import model.orm.exception.Order;
import model.orm.exception.RowNotFoundOrTooManyRowsException;
import model.orm.exception.Table;

public class AccessPrelevement {

	public AccessPrelevement() {
	}

	/**
	 * Recherche des Prelevement d'un compte à partir de son id.
	 *
	 * @param idNumCompte id du compte dont on cherche les prelevements
	 * @return Tous les Prelevements de idNumCompte (ou liste vide)
	 * @throws DataAccessException
	 * @throws DatabaseConnexionExceptions
	 */
	public ArrayList<Prelevement> getPrelevements(int idNumCompte)
			throws DataAccessException, DatabaseConnexionException {
		ArrayList<Prelevement> alResult = new ArrayList<>();

		try {
			Connection con = LogToDatabase.getConnexion();
			String query = "SELECT * FROM PrelevementAutomatique where idNumCompte = ?";
			query += " ORDER BY beneficiaire ASC";

			PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, idNumCompte);
			System.err.println(query);

			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				int idPrelev = rs.getInt("idPrelev");
				double montant = rs.getDouble("montant");
				int dateRecurrente = rs.getInt("dateRecurrente");
				String beneficiaire = rs.getString("beneficiaire");
				int idNumCpt = rs.getInt("idNumCompte");
				alResult.add(new Prelevement(idPrelev, montant, dateRecurrente, beneficiaire, idNumCpt));
			}
			rs.close();
			pst.close();
		} catch (SQLException e) {
			throw new DataAccessException(Table.PrelevementAutomatique, Order.SELECT, "Erreur accès", e);
		}

		return alResult;
	}

	/**
	 * Recherche d'un Prelevement à partir de son id (idNumCompte).
	 *
	 * @param idPrelev id du prelevement (clé primaire)
	 * @return Le prelevement ou null si non trouvé
	 * @throws RowNotFoundOrTooManyRowsException
	 * @throws DataAccessException
	 * @throws DatabaseConnexionException
	 */
	public Prelevement getPrelevement(int idPrelevement)
			throws RowNotFoundOrTooManyRowsException, DataAccessException, DatabaseConnexionException {
		try {
			Prelevement prelevementTrouvee;

			Connection con = LogToDatabase.getConnexion();

			String query = "SELECT * FROM PrelevementAutomatique where" + " idPrelev = ?";

			PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, idPrelevement);

			System.err.println(query);

			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
				int idPrelev = rs.getInt("idPrelev");
				double montant = rs.getDouble("montant");
				int dateRecurrente = rs.getInt("dateRecurrente");
				String beneficiaire = rs.getString("beneficiaire");
				int idNumCpt = rs.getInt("idNumCompte");
				prelevementTrouvee = new Prelevement(idPrelev, montant, dateRecurrente, beneficiaire, idNumCpt);
			} else {
				rs.close();
				pst.close();
				return null;
			}

			if (rs.next()) {
				throw new RowNotFoundOrTooManyRowsException(Table.PrelevementAutomatique, Order.SELECT,
						"Recherche anormale (en trouve au moins 2)", null, 2);
			}
			rs.close();
			pst.close();
			return prelevementTrouvee;
		} catch (SQLException e) {
			throw new DataAccessException(Table.PrelevementAutomatique, Order.SELECT, "Erreur accès", e);
		}
	}

	/**
	 * Création d'un Prelevement.
	 *
	 * p.idPrelev (clé primaire) doit exister seul 
	 *
	 * @param p IN p.idPrelev (clé primaire) doit exister seul
	 * @throws RowNotFoundOrTooManyRowsException
	 * @throws DataAccessException
	 * @throws DatabaseConnexionException
	 * @throws ManagementRuleViolation
	 */
	public void insertPrelevement(Prelevement p) throws RowNotFoundOrTooManyRowsException, DataAccessException,
	DatabaseConnexionException, ManagementRuleViolation {
		try {

			Connection con = LogToDatabase.getConnexion();

			String query = "INSERT INTO PrelevementAutomatique VALUES (seq_id_prelevAuto.NEXTVAL, ?, ?, ?, ?)";

			PreparedStatement pst = con.prepareStatement(query);
			pst.setDouble(1, p.montant);
			pst.setInt(2, p.dateRecurrente);
			pst.setString(3, p.beneficiaire);
			pst.setInt(4, p.idNumCompte);
			
			System.err.println(query);

			int result = pst.executeUpdate();
			pst.close();

			if (result != 1) {
				con.rollback();
				throw new RowNotFoundOrTooManyRowsException(Table.PrelevementAutomatique, Order.INSERT,
						"Insert anormal (insert de moins ou plus d'une ligne)", null, result);
			}
			con.commit();
		} catch (SQLException e) {
			throw new DataAccessException(Table.PrelevementAutomatique, Order.INSERT, "Erreur accès", e);
		}
	}
	
	/**
	 * Mise à jour d'un Prelevement.
	 *
	 * p.idPreleve (clé primaire) doit exister seul p.montant et p.dateRecurente est mis à jour
	 * p.idPreleve non mis à jour (un prelevement ne change pas de compte)
	 *
	 * @param p IN p.idPrelev (clé primaire) doit exister seul
	 * @throws RowNotFoundOrTooManyRowsException
	 * @throws DataAccessException
	 * @throws DatabaseConnexionException
	 * @throws ManagementRuleViolation
	 */
	public void updatePrelevement(Prelevement p) throws RowNotFoundOrTooManyRowsException, DataAccessException,
	DatabaseConnexionException, ManagementRuleViolation {
		try {
			
			Connection con = LogToDatabase.getConnexion();

			String query = "UPDATE PrelevementAutomatique SET " + "montant = ?, daterecurrente = ?" + "WHERE idPrelev = ?";

			PreparedStatement pst = con.prepareStatement(query);
			pst.setDouble(1, p.montant);
			pst.setInt(2, p.dateRecurrente);
			pst.setInt(3, p.idPrelev);

			System.err.println(query);

			int result = pst.executeUpdate();
			pst.close();
			if (result != 1) {
				con.rollback();
				throw new RowNotFoundOrTooManyRowsException(Table.CompteCourant, Order.UPDATE,
						"Update anormal (update de moins ou plus d'une ligne)", null, result);
			}
			con.commit();
		} catch (SQLException e) {
			throw new DataAccessException(Table.PrelevementAutomatique, Order.UPDATE, "Erreur accès", e);
		}
	}

	/**
	 * Suppression d'un Prélevement.
	 *
	 * cc.idNPrelev (clé primaire) doit exister seul le prélèvement est supprimé
	 * jour
	 *
	 * @param p IN Prelevement p
	 * @throws RowNotFoundOrTooManyRowsException
	 * @throws DataAccessException
	 * @throws DatabaseConnexionException
	 * @throws ManagementRuleViolation
	 */
	public void supprimerPrelevement(Prelevement p) throws RowNotFoundOrTooManyRowsException, DataAccessException,
	DatabaseConnexionException, ManagementRuleViolation {
		try {

			Connection con = LogToDatabase.getConnexion();

			String query = "DELETE FROM PrelevementAutomatique WHERE idPrelev = ?";

			PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, p.idPrelev);

			System.err.println(query);

			int result = pst.executeUpdate();
			
			pst.close();
			if (result != 1) {
				con.rollback();
				throw new RowNotFoundOrTooManyRowsException(Table.PrelevementAutomatique, Order.UPDATE,
						"Update anormal (update de moins ou plus d'une ligne)", null, result);
			}
			con.commit();
		} catch (SQLException e) {
			throw new DataAccessException(Table.PrelevementAutomatique, Order.UPDATE, "Erreur accès", e);
		}
	}
}