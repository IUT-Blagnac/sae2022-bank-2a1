package model.data;

public class Prelevement {
	public int idPrelev;
	public double montant;
	public int dateRecurrente;
	public String beneficiaire;
	public int idNumCompte;


	public Prelevement(int pfIdPrelev, double pfMontant, int pfDateRecurrente, String pfBeneficiaire, int pfIdNumCompte) {
		this.idPrelev=pfIdPrelev;
		this.montant=pfMontant;
		this.dateRecurrente=pfDateRecurrente;
		this.beneficiaire=pfBeneficiaire;
		this.idNumCompte=pfIdNumCompte;
	}

	public Prelevement(Prelevement pa) {
		this(pa.idPrelev,pa.montant,pa.dateRecurrente,pa.beneficiaire,pa.idNumCompte);
	}

	public Prelevement() {
		this(0,0,0,"",0);
	}
	
	@Override
	public String toString() {
		return "["+this.idPrelev+"] Montant = "+this.montant+", date =  "+this.dateRecurrente+" ("+this.beneficiaire+") {"+this.idNumCompte+"}";
	}
}

