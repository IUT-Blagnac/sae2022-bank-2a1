package model.data;

public class PrelevementAutomatique {
	public int idPrelev;
	public double montant;
	public int dateRecurrente;
	public String beneficiaire;
	public int idNumCompte;


	public PrelevementAutomatique(int pfIdPrelev, double pfMontant, int pfDateRecurrente, String pfBeneficiaire, int pfIdNumCompte) {
		this.idPrelev=pfIdPrelev;
		this.montant=pfMontant;
		this.dateRecurrente=pfDateRecurrente;
		this.beneficiaire=pfBeneficiaire;
		this.idNumCompte=pfIdNumCompte;
	}

	public PrelevementAutomatique(PrelevementAutomatique pa) {
		this(pa.idPrelev,pa.montant,pa.dateRecurrente,pa.beneficiaire,pa.idNumCompte);
	}

	public PrelevementAutomatique() {
		this(0,0,0,"",0);
	}
	
	@Override
	public String toString() {
		return "["+this.idPrelev+"] "+this.montant+" "+this.dateRecurrente+" ("+this.beneficiaire+") {"+this.idNumCompte+"}";
	}
}

