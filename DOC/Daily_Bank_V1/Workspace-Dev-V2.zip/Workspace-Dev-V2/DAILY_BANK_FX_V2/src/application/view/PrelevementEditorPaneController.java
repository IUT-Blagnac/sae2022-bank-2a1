package application.view;

import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;

import application.DailyBankState;
import application.tools.AlertUtilities;
import application.tools.ConstantesIHM;
import application.tools.EditionMode;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.data.Client;
import model.data.CompteCourant;
import model.data.PrelevementAutomatique;

public class PrelevementEditorPaneController implements Initializable {

	// Etat application
	private DailyBankState dbs;

	// Fenêtre physique
	private Stage primaryStage;

	// Données de la fenêtre
	private EditionMode em;
	private CompteCourant compteDuPrelevement;
	private PrelevementAutomatique prelevEdite;
	private PrelevementAutomatique prelevResult;

	// Manipulation de la fenêtre
	public void initContext(Stage _primaryStage, DailyBankState _dbstate) {
		this.primaryStage = _primaryStage;
		this.dbs = _dbstate;
		this.configure();
	}

	private void configure() {
		this.primaryStage.setOnCloseRequest(e -> this.closeWindow(e));

		//this.txtDecAutorise.focusedProperty().addListener((t, o, n) -> this.focusDecouvert(t, o, n));
		//this.txtSolde.focusedProperty().addListener((t, o, n) -> this.focusSolde(t, o, n));
	}

	public PrelevementAutomatique displayDialog(CompteCourant cpt, PrelevementAutomatique prelev, EditionMode mode) {
		this.compteDuPrelevement = cpt;
		this.em = mode;
		if (prelev == null) {
			this.prelevEdite = new PrelevementAutomatique(0, 0, 1, "", this.compteDuPrelevement.idNumCompte); // A FAIRE PAS OUBLIER
		} else {
			this.prelevEdite = new PrelevementAutomatique(prelev);
		}
		this.prelevResult = null;
		this.txtIdPrelev.setDisable(true);
		this.txtIdNumCompte.setDisable(true);
		switch (mode) {
		case CREATION:
			this.txtDateRecc.setDisable(false);
			this.txtBeneficiaire.setEditable(true);
			this.txtBeneficiaire.setDisable(false);
			this.txtMontant.setDisable(false);
			this.lblMessage.setText("Informations sur le nouveau prélèvement");
			this.btnOk.setText("Ajouter");
			this.btnCancel.setText("Annuler");
			break;
		case MODIFICATION:
			this.txtDateRecc.setDisable(false);
			this.txtBeneficiaire.setDisable(true);
			this.txtMontant.setDisable(false);
			this.lblMessage.setText("Informations sur le prélèvement");
			this.btnOk.setText("Modifier");
			this.btnCancel.setText("Annuler");
			break;
		}

		// Paramétrages spécifiques pour les chefs d'agences
		if (ConstantesIHM.isAdmin(this.dbs.getEmpAct())) {
			// rien pour l'instant
		}

		// initialisation du contenu des champs
		this.txtIdPrelev.setText("" + this.prelevEdite.idPrelev);
		this.txtIdNumCompte.setText("" + this.prelevEdite.idNumCompte);
		this.txtDateRecc.setText("" + this.prelevEdite.dateRecurrente);
		this.txtBeneficiaire.setText("" + this.prelevEdite.beneficiaire);
		this.txtMontant.setText(""+this.prelevEdite.montant);

		this.prelevResult = null;
		this.primaryStage.showAndWait();
		return this.prelevResult;
	}

	// Gestion du stage
	private Object closeWindow(WindowEvent e) {
		this.doCancel();
		e.consume();
		return null;
	}

	// Attributs de la scene + actions
	@FXML
	private Label lblMessage;
	@FXML
	private TextField txtIdPrelev;
	@FXML
	private TextField txtIdNumCompte;
	@FXML
	private TextField txtMontant;
	@FXML
	private TextField txtDateRecc;
	@FXML
	private TextField txtBeneficiaire;
	@FXML
	private Button btnOk;
	@FXML
	private Button btnCancel;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
	}

	/**
	 * Annule la procédure d'édition de compte
	 */
	@FXML
	private void doCancel() {
		this.prelevResult = null;
		this.primaryStage.close();
	}

	/**
	 * Ajoute un compte à la liste des comptes de l'utilisateur
	 */
	@FXML
	private void doAjouter() {
		switch (this.em) {
		case CREATION:
			if (this.isSaisieValide()) {
				this.prelevResult = this.prelevEdite;
				this.primaryStage.close();
			}
			break;
		case MODIFICATION:
			if (this.isSaisieValide()) {
				this.prelevResult = this.prelevEdite;
				this.primaryStage.close();
			}
		}
	}

	/**
	 * Regarde si la saisie des champs d'édition du client sont valides
	 * 
	 * @return boolean
	 */
	private boolean isSaisieValide() {
		if (this.txtBeneficiaire.getText().isEmpty()) {
			AlertUtilities.showAlert(this.primaryStage, "Erreur de saisie", null, "Le champ bénéficiaire ne doit pas être vide",
					AlertType.WARNING);
			this.txtBeneficiaire.setStyle("-fx-text-fill:red; -fx-border-color : red;");
			this.txtBeneficiaire.requestFocus();
			return false;
		}
		if (this.txtBeneficiaire.getText().length()>50) {
			AlertUtilities.showAlert(this.primaryStage, "Erreur de saisie", null, "Le champ bénéficiaire ne doit pas faire plus de 50 caractères",
					AlertType.WARNING);
			this.txtBeneficiaire.setStyle("-fx-text-fill:red; -fx-border-color : red;");
			this.txtBeneficiaire.requestFocus();
			return false;
		}
		this.txtBeneficiaire.setStyle("-fx-text-fill:black; -fx-border-color : none;");
		if (this.txtDateRecc.getText().isEmpty()) {
			AlertUtilities.showAlert(this.primaryStage, "Erreur de saisie", null, "Le champ date récurrente ne doit pas être vide",
					AlertType.WARNING);
			this.txtDateRecc.setStyle("-fx-text-fill:red; -fx-border-color : red;");
			this.txtDateRecc.requestFocus();
			return false;
		}
		if (this.txtDateRecc.getText().length()>2) {
			AlertUtilities.showAlert(this.primaryStage, "Erreur de saisie", null, "Le champ date récurrente ne doit pas faire plus de 2 caractères",
					AlertType.WARNING);
			this.txtDateRecc.setStyle("-fx-text-fill:red; -fx-border-color : red;");
			this.txtDateRecc.requestFocus();
			return false;
		}
		try {
			int dateRecc = Integer.parseInt(this.txtDateRecc.getText().trim());
			if(dateRecc>31 || dateRecc<1) {
				AlertUtilities.showAlert(this.primaryStage, "Erreur de saisie", null, "Le champ date récurrente ne doit pas être supérieur à 31 et ne doit pas être inférieur à 0",
						AlertType.WARNING);
				this.txtDateRecc.setStyle("-fx-text-fill:red; -fx-border-color : red;");
				this.txtDateRecc.requestFocus();
				return false;
			}
		} catch (Exception e) {
			AlertUtilities.showAlert(this.primaryStage, "Erreur de saisie", null, "Le champ date récurrente doit être un nombre",
					AlertType.WARNING);
			this.txtDateRecc.setStyle("-fx-text-fill:red; -fx-border-color : red;");
			this.txtDateRecc.requestFocus();
			return false;
		}
		this.txtDateRecc.setStyle("-fx-text-fill:black; -fx-border-color : none;");
		if (this.txtMontant.getText().isEmpty()) {
			AlertUtilities.showAlert(this.primaryStage, "Erreur de saisie", null, "Le champ montant ne doit pas être vide",
					AlertType.WARNING);
			this.txtMontant.setStyle("-fx-text-fill:red; -fx-border-color : red;");
			this.txtMontant.requestFocus();
			return false;
		}
		if (this.txtMontant.getText().length()>8) {
			AlertUtilities.showAlert(this.primaryStage, "Erreur de saisie", null, "Le champ montant ne doit pas faire plus de 8 caractères",
					AlertType.WARNING);
			this.txtMontant.setStyle("-fx-text-fill:red; -fx-border-color : red;");
			this.txtMontant.requestFocus();
			return false;
		}
		try {
			double montant = Double.parseDouble(this.txtMontant.getText().trim());
			if(montant<=0) {
				AlertUtilities.showAlert(this.primaryStage, "Erreur de saisie", null, "Le champ montant ne doit pas être inférieur à 0",
						AlertType.WARNING);
				this.txtMontant.setStyle("-fx-text-fill:red; -fx-border-color : red;");
				this.txtMontant.requestFocus();
				return false;
			}
		} catch (Exception e) {
			AlertUtilities.showAlert(this.primaryStage, "Erreur de saisie", null, "Le champ montant doit être un nombre",
					AlertType.WARNING);
			this.txtMontant.setStyle("-fx-text-fill:red; -fx-border-color : red;");
			this.txtMontant.requestFocus();
			return false;
		}
		this.prelevEdite.beneficiaire = this.txtBeneficiaire.getText().trim();
		this.prelevEdite.dateRecurrente = Integer.parseInt(this.txtDateRecc.getText().trim());
		this.prelevEdite.montant = Double.parseDouble(this.txtMontant.getText().trim());
		return true;
	}
}
