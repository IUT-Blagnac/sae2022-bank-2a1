package application.view;

import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import java.awt.Desktop;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import application.DailyBankState;
import application.control.OperationsManagement;
import application.tools.AlertUtilities;
import application.tools.NoSelectionModel;
import application.tools.PairsOfValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.data.Client;
import model.data.CompteCourant;
import model.data.Operation;

public class OperationsManagementController implements Initializable {

	// Etat application
	private DailyBankState dbs;
	private OperationsManagement om;

	// Fenêtre physique
	private Stage primaryStage;

	// Données de la fenêtre
	private Client clientDuCompte;
	private CompteCourant compteConcerne;
	private ObservableList<Operation> olOperation;
	private String MoisAnneeConcerne;
	private String pdfFileName;

	// Manipulation de la fenêtre
	public void initContext(Stage _primaryStage, OperationsManagement _om, DailyBankState _dbstate, Client client, CompteCourant compte) {
		this.primaryStage = _primaryStage;
		this.dbs = _dbstate;
		this.om = _om;
		this.clientDuCompte = client;
		this.compteConcerne = compte;
		this.configure();
	}

	private void configure() {
		this.primaryStage.setOnCloseRequest(e -> this.closeWindow(e));

		this.olOperation = FXCollections.observableArrayList();
		this.lvOperations.setItems(this.olOperation);
		this.lvOperations.setSelectionModel(new NoSelectionModel<Operation>());
		this.updateInfoCompteClient();
		this.validateComponentState();
		
		this.cbMois.getSelectionModel().selectedItemProperty().addListener(e -> this.validateComponentState());
		this.configComboBox();
		this.txtNomFichierPdf.setText("Choisir le nom de fichier");
		this.btnValidNomPDF.setDisable(true);
	}
	
	/**
	 * Permet de configurer les choix de mois différent dans le combobox cbMois.
	 */
	private void configComboBox() {
		java.util.Date now = new java.util.Date();
		java.sql.Date todaysDate = new java.sql.Date(now.getTime());
		int nbOp = this.olOperation.size();
		ObservableList<String> list = FXCollections.observableArrayList();
		for(int i = 0;i<nbOp;i++) {
			if(this.olOperation.get(i).dateOp.getYear() < todaysDate.getYear() || (this.olOperation.get(i).dateOp.getYear() == todaysDate.getYear() && this.olOperation.get(i).dateOp.getMonth() <todaysDate.getMonth())) {

				Calendar cal = Calendar.getInstance();
				cal.setTime(this.olOperation.get(i).dateOp);
				//System.out.println("Mois : "+(cal.get(Calendar.MONTH)+1)+"-"+cal.get(Calendar.YEAR));
				//System.out.println(this.olOperation.get(i).dateOp.toString());
				list.add((cal.get(Calendar.MONTH)+1)+"-"+cal.get(Calendar.YEAR));
			}
		}
		this.cbMois.setItems(list);
	}
	
	public void displayDialog() {
		this.primaryStage.showAndWait();
	}

	// Gestion du stage
	private Object closeWindow(WindowEvent e) {
		this.doCancel();
		e.consume();
		return null;
	}

	// Attributs de la scene + actions
	@FXML
	private Label lblInfosClient;
	@FXML
	private Label lblInfosCompte;
	@FXML
	private ListView<Operation> lvOperations;
	@FXML
	private Button btnDebit;
	@FXML
	private Button btnCredit;
	@FXML
	private Button btnVirement;
	@FXML
	private ComboBox<String> cbMois;
	@FXML
	private Button btnGenererPdf;
	@FXML
	private TextField txtNomFichierPdf;
	@FXML
	private Button btnValidNomPDF;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
	}

	/**
	 * Permet de fermer la page ouverte
	 */
	@FXML
	private void doCancel() {
		this.primaryStage.close();
	}

	/**
	 * Permet d'enregistrer un débit sur un compte
	 */
	@FXML
	private void doDebit() {

		Operation op = this.om.enregistrerDebit();
		if (op != null) {
			this.updateInfoCompteClient();
			this.validateComponentState();
		}
	}

	/**
	 * Permet d'enregistrer un crédit sur un compte
	 */
	@FXML
	private void doCredit() {

		Operation op = this.om.enregistrerCredit();
		if (op != null) {
			this.updateInfoCompteClient();
			this.validateComponentState();
		}
	}

	/**
	 * Permet d'enregistrer un virement entre deux comptes
	 */
	@FXML
	private void doVirement() {
		Operation op = this.om.enregistrerVirement();
		if (op != null) {
			this.updateInfoCompteClient();
			this.validateComponentState();
		}
	}

	/**
	 * Permet de voir les prélevement automatique
	 */
	@FXML
	private void doPrelevementAuto() {
		this.om.gererPrelevements(this.compteConcerne);
		this.validateComponentState();
	}
	
	/**
	 * Permet de générer un relevé mensuel d'un compte en pdf + ouvre ce PDF
	 * 
	 */
	@FXML
	private void doGenererPdf() throws ParseException {
		String FILE = ".\\src\\"+pdfFileName+".pdf";


		try {
			Document document = new Document();
			PdfWriter.getInstance(document, new FileOutputStream(FILE));
			document.open();
			addContent(document);
			document.close();
			Desktop.getDesktop().open(new File(FILE));
		} catch (FileNotFoundException e) {
			AlertUtilities.showAlert(this.primaryStage, "Fichier indésirable", null, "Le fichier saisi existe déjà et est en cours d'utilisation.",
					AlertType.WARNING);
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Rajoute le contenu voulu d'un document dans ce dernier.
	 * 
	 * @param document le document que l'on veut écrire
	 * @throws DocumentException
	 */
	private void addContent(Document document)
			throws DocumentException {
		Font catFont = new Font(Font.FontFamily.HELVETICA, 18,
				Font.BOLD , BaseColor.RED);
		Font smallBold = new Font(Font.FontFamily.TIMES_ROMAN, 12,
				Font.BOLD);


		Paragraph preface = new Paragraph();

		Paragraph source = new Paragraph("Raport générée par : " + this.dbs.getEmpAct().nom+" "+this.dbs.getEmpAct().prenom, smallBold);
		source.setAlignment(com.itextpdf.text.Element.ALIGN_RIGHT);
		preface.add(source);

		Paragraph date = new Paragraph("Le : "+ LocalDate.now().toString());
		date.setAlignment(com.itextpdf.text.Element.ALIGN_RIGHT);
		preface.add(date);

		addEmptyLine(preface, 1);

		//Ajout du titre
		Paragraph titre = new Paragraph("Relevé mensuel du "+this.MoisAnneeConcerne, catFont);
		titre.setAlignment(com.itextpdf.text.Element.ALIGN_CENTER);
		preface.add(titre);

		addEmptyLine(preface, 3);

		preface.add(new Paragraph("Relevé mensuel du compte n°"+this.compteConcerne.idNumCompte+" de "+this.clientDuCompte.nom+" "+this.clientDuCompte.prenom+" (id client :"+this.clientDuCompte.idNumCli+")"));
		addEmptyLine(preface, 1);
		

		Date selectedDate;
		try {
			selectedDate = new SimpleDateFormat("MM-yyyy").parse(this.cbMois.getSelectionModel().getSelectedItem());
			int nbOp = this.olOperation.size();
			ObservableList<Operation> olOperationCompteConcerne = FXCollections.observableArrayList();
			for(int i = 0;i<nbOp;i++) {
				if(this.olOperation.get(i).dateOp.getYear() == selectedDate.getYear() &&  this.olOperation.get(i).dateOp.getMonth() == selectedDate.getMonth()) {
					olOperationCompteConcerne.add(this.olOperation.get(i));
				}
			}
			int taille = olOperationCompteConcerne.size();
			for(int i =0;i<taille;i++) {
				Paragraph operation = new Paragraph(olOperationCompteConcerne.get(i).toString(), smallBold);
				operation.setFirstLineIndent(50);
				preface.add(new Paragraph(operation));
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}  

		document.add(preface);
		document.newPage();

	}

	/**
	 * Saute un nombre de ligne défini dans un paragraphe
	 * 
	 * @param paragraph le paragraphe
	 * @param number le nombre de ligne à sauter
	 */
	private void addEmptyLine(Paragraph paragraph, int number) {
		for (int i = 0; i < number; i++) {
			paragraph.add(new Paragraph(" "));
		}
	}

	/**
	 * Supprimer le texte du textfield txtNomFichierPdf lorsque l'on clic dessus et que le contenu de ce dernier est égal à "Choisir le nom de fichier"
	 */
	@FXML
	private void suppTexte() {
		if (this.txtNomFichierPdf.getText().compareTo("Choisir le nom de fichier") == 0) {
			this.txtNomFichierPdf.setText("");
		}
	}

	/**
	 * A chaque pression de clavier, test si le nom du PDF est vamide.Si oui, active le bouton de validation de nom de pdf (btnValidNomPDF) et sinon le désactive.
	 */
	@FXML 
	private void doValiderNomPDF() {
		if(this.txtNomFichierPdf.getText().length() !=0) {
			this.btnValidNomPDF.setDisable(false);
		} else {
			this.btnValidNomPDF.setDisable(true);
		}
	}

	/**
	 * Valide et enregistre le nom du PDF
	 */
	@FXML
	private void doEnregistrerNomPDF() {
		this.pdfFileName = this.txtNomFichierPdf.getText();
		this.btnValidNomPDF.setDisable(true);
		this.txtNomFichierPdf.setDisable(true);
		this.validateComponentState();
	}

	/**
	 * Active/désactive les boutons crédit, débit et virement si le compte est cloturé ou non
	 */
	private void validateComponentState() {
		if(compteConcerne.estCloture.compareTo("N")==0) {
			this.btnCredit.setDisable(false);
			this.btnDebit.setDisable(false);
			this.btnVirement.setDisable(false);
		} else {
			this.btnCredit.setDisable(true);
			this.btnDebit.setDisable(true);
			this.btnVirement.setDisable(true);
		}
		
		String selected = this.cbMois.getSelectionModel().getSelectedItem();
		this.MoisAnneeConcerne = selected;
		if(selected == null  || this.pdfFileName == null) {
			this.btnGenererPdf.setDisable(true);
		} else {
			this.btnGenererPdf.setDisable(false);

		}
	}

	private void updateInfoCompteClient() {

		PairsOfValue<CompteCourant, ArrayList<Operation>> opesEtCompte;

		opesEtCompte = this.om.operationsEtSoldeDunCompte();

		ArrayList<Operation> listeOP;
		this.compteConcerne = opesEtCompte.getLeft();
		listeOP = opesEtCompte.getRight();

		String info;
		info = this.clientDuCompte.nom + "  " + this.clientDuCompte.prenom + "  (id : " + this.clientDuCompte.idNumCli
				+ ")";
		this.lblInfosClient.setText(info);

		info = "Cpt. : " + this.compteConcerne.idNumCompte + "  "
				+ String.format(Locale.ENGLISH, "%12.02f", this.compteConcerne.solde) + "  /  "
				+ String.format(Locale.ENGLISH, "%8d", this.compteConcerne.debitAutorise);
		this.lblInfosCompte.setText(info);

		this.olOperation.clear();
		for (Operation op : listeOP) {
			this.olOperation.add(op);
		}

		this.validateComponentState();
	}
}
