package application.view;

import java.net.URL;
import java.util.ResourceBundle;

import application.DailyBankState;
import application.control.ListeSimulation;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class SimulationController implements Initializable {

	private Stage primaryStage;
	private DailyBankState dbs;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
	}

	public void initContext(Stage _primaryStage, DailyBankState _dbstate) {
		this.primaryStage = _primaryStage;
		this.dbs = _dbstate;
		this.configure();
	}

	private void configure() {
		this.primaryStage.setOnCloseRequest(e -> this.closeWindow(e));
	}

	private Object closeWindow(WindowEvent e) {
		this.doCancel();
		e.consume();
		return null;
	}

	private void doCancel() {
		this.primaryStage.close();
	}
	
	@FXML
	private TextField txtMontantEmprunt1;
	@FXML
	private TextField txtDureeEmprunt1;
	@FXML
	private TextField txtTauxEmprunt1;
	@FXML
	private TextField txtMontantEmprunt2;
	@FXML
	private TextField txtDureeEmprunt2;
	@FXML
	private TextField txtTauxEmprunt2;
	@FXML
	private TextField txtTauxAssurance;
	
	
	/**
	 * Permet de lancer l'action de simulation d'emprunt
	 */
	@FXML
	public void actionSimulerEmprunt () {
		
		try {
			
			double montantEmprunt = Double.parseDouble(this.txtMontantEmprunt1.getText());
			int dureeEmprunt = Integer.parseInt(this.txtDureeEmprunt1.getText());
			double tauxEmprunt = Double.parseDouble(this.txtTauxEmprunt1.getText());
			
			if (montantEmprunt <= 0)
				throw new NumberFormatException();
			if (dureeEmprunt <= 0)
				throw new NumberFormatException();
			if (tauxEmprunt <= 0)
				throw new NumberFormatException();
			
			if (dureeEmprunt > 250) {
				
				Alert alert = new Alert (AlertType.INFORMATION);
				alert.setHeaderText(null);
				alert.setTitle("Erreur");
				alert.setContentText("La durée d'un emprunt ne doit pas excéder 25 ans (250 mois).");
				alert.showAndWait();
				
			} else if (tauxEmprunt > 100) {
				
				Alert alert = new Alert (AlertType.INFORMATION);
				alert.setHeaderText(null);
				alert.setTitle("Erreur");
				alert.setContentText("Le taux d'intérêts ne doit pas être supérieur à 100");
				alert.showAndWait();
				
			} else {
				
				ListeSimulation ls = new ListeSimulation (primaryStage, dbs, montantEmprunt, dureeEmprunt, tauxEmprunt);
			
			}
			
		} catch (NumberFormatException nfe) {
			Alert alert = new Alert (AlertType.INFORMATION);
			alert.setHeaderText(null);
			alert.setTitle("Erreur");
			alert.setContentText("Tous les champs doivent être remplis et corrects");
			alert.showAndWait();
			
		}
	}
	
	/**
	 * Permet de lancer l'action de simulation d'assurance d'emprunt
	 */
	@FXML
	public void actionSimulerAssurance () {
		
		try {
			
			double montantEmprunt = Double.parseDouble(this.txtMontantEmprunt2.getText());
			int dureeEmprunt = Integer.parseInt(this.txtDureeEmprunt2.getText());
			double tauxEmprunt = Double.parseDouble(this.txtTauxEmprunt2.getText());
			double tauxAssurance = Double.parseDouble(this.txtTauxAssurance.getText());
			
			if (montantEmprunt <= 0)
				throw new NumberFormatException();
			if (dureeEmprunt <= 0)
				throw new NumberFormatException();
			if (tauxEmprunt <= 0)
				throw new NumberFormatException();
			if (tauxAssurance <= 0)
				throw new NumberFormatException();
			
			if (dureeEmprunt > 250) {
				
				Alert alert = new Alert (AlertType.INFORMATION);
				alert.setHeaderText(null);
				alert.setTitle("Erreur");
				alert.setContentText("La durée d'un emprunt ne doit pas excéder 25 ans (250 mois).");
				alert.showAndWait();
				
			} else if (tauxEmprunt > 100) {
				
				Alert alert = new Alert (AlertType.INFORMATION);
				alert.setHeaderText(null);
				alert.setTitle("Erreur");
				alert.setContentText("Le taux d'intérêts ne doit pas être supérieur à 100");
				alert.showAndWait();
				
			} else if (tauxAssurance > 100) {
				
				Alert alert = new Alert (AlertType.INFORMATION);
				alert.setHeaderText(null);
				alert.setTitle("Erreur");
				alert.setContentText("Le taux d'assurance ne doit pas être supérieur à 100");
				alert.showAndWait();
				
			} else {
				
				ListeSimulation ls = new ListeSimulation (primaryStage, dbs, montantEmprunt, dureeEmprunt, tauxEmprunt, tauxAssurance);
			
			}
			
		} catch (NumberFormatException nfe) {
			Alert alert = new Alert (AlertType.INFORMATION);
			alert.setHeaderText(null);
			alert.setTitle("Erreur");
			alert.setContentText("Tous les champs doivent être remplis et corrects");
			alert.showAndWait();
		}
			
		}
	

	/**
	 * Permet de lancer l'action de remplissage automatique de la simulation d'emprunt
	 */
	@FXML
	public  void actionRemplir1 () {
		if (this.txtMontantEmprunt2.getText().equals("")) {
			this.txtMontantEmprunt1.setText("40000");
		} else {
			this.txtMontantEmprunt1.setText(this.txtMontantEmprunt2.getText());
		}
		
		if (this.txtDureeEmprunt2.getText().equals("")) {
			this.txtDureeEmprunt1.setText("120");
		} else {
			this.txtDureeEmprunt1.setText(this.txtDureeEmprunt2.getText());
		}
		
		if (this.txtTauxEmprunt2.getText().equals("")) {
			this.txtTauxEmprunt1.setText("0.8");
		} else {
			this.txtTauxEmprunt1.setText(this.txtTauxEmprunt2.getText());
		}
	}
	
	/**
	 * Permet de lancer l'action de remplissage automatique de la simulation d'assurance d'emprunt
	 */
	@FXML
	public void actionRemplir2 () {
		if (this.txtMontantEmprunt1.getText().equals("")) {
			this.txtMontantEmprunt2.setText("40000");
		} else {
			this.txtMontantEmprunt2.setText(this.txtMontantEmprunt1.getText());
		}
		
		if (this.txtDureeEmprunt1.getText().equals("")) {
			this.txtDureeEmprunt2.setText("120");
		} else {
			this.txtDureeEmprunt2.setText(this.txtDureeEmprunt1.getText());
		}
		
		if (this.txtTauxEmprunt1.getText().equals("")) {
			this.txtTauxEmprunt2.setText("0.8");
		} else {
			this.txtTauxEmprunt2.setText(this.txtTauxEmprunt1.getText());
		}
		
		this.txtTauxAssurance.setText("0.3");
	}

	
}
