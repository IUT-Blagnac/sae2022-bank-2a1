package application.view;

import java.net.URL;
import java.util.ResourceBundle;

import application.DailyBankState;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


public class ListeSimulationController implements Initializable {

	private Stage primaryStage;
	private DailyBankState dbs;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
	}

	public void initContext(Stage _primaryStage, DailyBankState _dbstate) {
		this.primaryStage = _primaryStage;
		this.dbs = _dbstate;
		this.configure();
	}

	private void configure() {
		this.primaryStage.setOnCloseRequest(e -> this.closeWindow(e));
	}

	private Object closeWindow(WindowEvent e) {
		this.doCancel();
		e.consume();
		return null;
	}

	private void doCancel() {
		this.primaryStage.close();
	}
	

	/**
	 * Calcule les valeurs de la simulation d'emprunt et renvoie un tableau de label contenant 6 labels,
	 * chacun avec 1 type de valeurs (mois, montant début, intérêts, principal, mensualité, montant fin)
	 * 
	 * @param montantEmprunt
	 * @param tauxEmprunt
	 * @param dureeEmprunt
	 * @return un tableau de Labels
	 */
	public Label [] doCalculEmprunt (double montantEmprunt, double tauxEmprunt, int dureeEmprunt) {
		
		Label tab [] = new Label [6];
		
		double mensualite = (montantEmprunt * tauxEmprunt* power (1+tauxEmprunt, dureeEmprunt) / (power (1+tauxEmprunt, dureeEmprunt) - 1));
		
		int mois = 0;
		double montantDebut = montantEmprunt;
		double montantFin = montantEmprunt;
		double interets;
		double principal;
		String chaineMois = "Mois\n\n\n";
		String chaineMontantDebut = "Capital restant\n(début de mois)\n\n";
		String chaineMontantFin = "Capital restant\n(fin de mois)\n\n";
		String chaineMensualite = "Mensualité\n\n\n";
		String chainePrincipal = "Principal\n\n\n";
		String chaineInterets = "Intérêts\n\n\n";
		
		for (int i = 0; i < dureeEmprunt; i++) {
			mois  += 1;
			if (montantDebut != montantFin)
				montantDebut = montantFin;
			interets = montantDebut * tauxEmprunt;
			principal = mensualite - interets;
			montantFin -= principal;
			
			chaineInterets += (double) Math.round(interets * 100) / 100 + "\n";
			chaineMois += mois + "\n";
			chaineMontantDebut += (double) Math.round(montantDebut * 100) / 100 + "\n";
			chaineMontantFin += (double) Math.round(montantFin * 100) / 100 + "\n";
			chaineMensualite += (double) Math.round(mensualite * 100) / 100 + "\n";
			chainePrincipal += (double) Math.round(principal * 100) / 100 + "\n";
			
		}
		
		String style1 = "-fx-padding: 10px;";
		String style2 = "-fx-padding: 10px; -fx-font-weight : bold;";
	
		Label lbl1 = new Label () ;
		lbl1.setText(chaineMois);
		lbl1.setMinWidth(60);
		lbl1.setStyle(style2);
		
		Label lbl2 = new Label () ;
		lbl2.setText(chaineMontantDebut);
		lbl2.setMinWidth(60);
		lbl2.setStyle(style1);
		
		Label lbl3 = new Label () ;
		lbl3.setText(chaineInterets);
		lbl3.setMinWidth(60);
		lbl3.setStyle(style2);
		
		Label lbl4 = new Label () ;
		lbl4.setText(chainePrincipal);
		lbl4.setMinWidth(60);
		lbl4.setStyle(style1);
		
		Label lbl5 = new Label () ;
		lbl5.setText(chaineMensualite);
		lbl5.setMinWidth(60);
		lbl5.setStyle(style2);
		
		Label lbl6 = new Label () ;
		lbl6.setText(chaineMontantFin);
		lbl6.setMinWidth(60);
		lbl6.setStyle(style1);
		
		tab [0] = lbl1;
		tab [1] = lbl2;
		tab [2] = lbl3;
		tab [3] = lbl4;
		tab [4] = lbl5;
		tab [5] = lbl6;
		
		return tab;
		
	}
	
	private static double power(double N, int P) {
        if (P == 0)
            return 1;
        else
            return N * power(N, P - 1);
    }

	/**
	 * Calcule les valeurs de la simulation d'assurance d'emprunt et renvoie un tableau de label contenant 8 labels,
	 * chacun avec 1 type de valeurs (mois, montant début, intérêts, principal, mensualité, cout assruance, mensualité
	 * avec assurance, montant fin)
	 * 
	 * @param montantEmprunt
	 * @param tauxEmprunt
	 * @param dureeEmprunt
	 * @param tauxAssurance
	 * @return un tableau de Labels
	 */
	public Label[] doCalculAssurance(double montantEmprunt, double tauxEmprunt, int dureeEmprunt, double tauxAssurance) {
		
		Label tab [] = new Label [8];
		

		double montantAssurance = tauxEmprunt * montantEmprunt / 12;
		
		double mensualite = (montantEmprunt * tauxEmprunt* power (1+tauxEmprunt, dureeEmprunt) / (power (1+tauxEmprunt, dureeEmprunt) - 1));
		
		int mois = 0;
		double montantDebut = montantEmprunt;
		double montantFin = montantEmprunt;
		double interets;
		double principal;
		String chaineMois = "Mois\n\n\n";
		String chaineMontantDebut = "Capital restant\n(début de mois)\n\n";
		String chaineMontantFin = "Capital restant\n(fin de mois)\n\n";
		String chaineMensualite = "Mensualité sans\nassurance\n\n";
		String chainePrincipal = "Principal\n\n\n";
		String chaineInterets = "Intérêts\n\n\n";
		String chaineAssurance = "Coût assurance\n\n\n";
		String chaineMensuAssurance = "Mensualité avec\nassurance\n\n";
		
		for (int i = 0; i < dureeEmprunt; i++) {
			mois  += 1;
			if (montantDebut != montantFin)
				montantDebut = montantFin;
			interets = montantDebut * tauxEmprunt;
			principal = mensualite - interets;
			montantFin -= principal;
			
			chaineInterets += (double) Math.round(interets * 100) / 100 + "\n";
			chaineMois += mois + "\n";
			chaineMontantDebut += (double) Math.round(montantDebut * 100) / 100 + "\n";
			chaineMontantFin += (double) Math.round(montantFin * 100) / 100 + "\n";
			chaineMensualite += (double) Math.round(mensualite * 100) / 100 + "\n";
			chainePrincipal += (double) Math.round(principal * 100) / 100 + "\n";
			chaineAssurance += (double) Math.round(montantAssurance * 100) / 100 + "\n";
			chaineMensuAssurance += (double) Math.round ((mensualite + montantAssurance) * 100) / 100 + "\n";
			
		}
		
		String style1 = "-fx-padding: 10px;";
		String style2 = "-fx-padding: 10px; -fx-font-weight : bold;";
		
	
		Label lbl1 = new Label () ;
		lbl1.setText(chaineMois);
		lbl1.setMinWidth(60);
		lbl1.setStyle(style2);
		
		Label lbl2 = new Label () ;
		lbl2.setText(chaineMontantDebut);
		lbl2.setMinWidth(60);
		lbl2.setStyle(style1);
		
		Label lbl3 = new Label () ;
		lbl3.setText(chaineInterets);
		lbl3.setMinWidth(60);
		lbl3.setStyle(style2);
		
		Label lbl4 = new Label () ;
		lbl4.setText(chainePrincipal);
		lbl4.setMinWidth(60);
		lbl4.setStyle(style1);
		
		Label lbl5 = new Label () ;
		lbl5.setText(chaineMensualite);
		lbl5.setMinWidth(60);
		lbl5.setStyle(style2);
		
		Label lbl6 = new Label () ;
		lbl6.setText(chaineAssurance);
		lbl6.setMinWidth(60);
		lbl6.setStyle(style1);
		
		Label lbl7 = new Label () ;
		lbl7.setText(chaineMensuAssurance);
		lbl7.setMinWidth(60);
		lbl7.setStyle(style2);
		
		Label lbl8 = new Label () ;
		lbl8.setText(chaineMontantFin);
		lbl8.setMinWidth(60);
		lbl8.setStyle(style1);
		
		tab [0] = lbl1;
		tab [1] = lbl2;
		tab [2] = lbl3;
		tab [3] = lbl4;
		tab [4] = lbl5;
		tab [5] = lbl6;
		tab [6] = lbl7;
		tab [7] = lbl8;
		
		return tab;
		
	}
	
}