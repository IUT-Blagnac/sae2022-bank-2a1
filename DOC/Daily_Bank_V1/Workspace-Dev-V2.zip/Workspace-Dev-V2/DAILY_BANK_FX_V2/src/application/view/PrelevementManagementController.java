package application.view;

import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;
import java.util.ResourceBundle;

import application.DailyBankState;
import application.control.OperationsManagement;
import application.control.PrelevementManagement;
import application.tools.NoSelectionModel;
import application.tools.PairsOfValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.data.Client;
import model.data.CompteCourant;
import model.data.Operation;
import model.data.PrelevementAutomatique;

public class PrelevementManagementController implements Initializable {

	// Etat application
	private DailyBankState dbs;
	private PrelevementManagement pm;

	// Fenêtre physique
	private Stage primaryStage;

	// Données de la fenêtre
	private CompteCourant compteDuPrelevement;
	private PrelevementAutomatique prelevementConcerne;
	private ObservableList<PrelevementAutomatique> olPrelevement;

	// Manipulation de la fenêtre
	public void initContext(Stage _primaryStage, PrelevementManagement _pm, DailyBankState _dbstate, CompteCourant compte, PrelevementAutomatique prelevement) {
		this.primaryStage = _primaryStage;
		this.dbs = _dbstate;
		this.pm = _pm;
		this.compteDuPrelevement = compte;
		this.prelevementConcerne = prelevement;
		this.configure();
	}

	private void configure() {
		this.primaryStage.setOnCloseRequest(e -> this.closeWindow(e));

		this.olPrelevement = FXCollections.observableArrayList();
		this.lvPrelevement.setItems(this.olPrelevement);
		this.lvPrelevement.setSelectionModel(new NoSelectionModel<PrelevementAutomatique>());
		this.updateInfoPrelevementCompte();
		this.validateComponentState();
	}

	public void displayDialog() {
		this.primaryStage.showAndWait();
	}

	// Gestion du stage
	private Object closeWindow(WindowEvent e) {
		this.doCancel();
		e.consume();
		return null;
	}

	// Attributs de la scene + actions
	@FXML
	private Label lblInfosClient;
	@FXML
	private Label lblInfosCompte;
	@FXML
	private ListView<PrelevementAutomatique> lvPrelevement;
	@FXML
	private Button btnDebit;
	@FXML
	private Button btnCredit;
	@FXML
	private Button btnVirement;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
	}

	/**
	 * Permet de fermer la page ouverte
	 */
	@FXML
	private void doCancel() {
		this.primaryStage.close();
	}

	/**
	 * Permet d'enregistrer un débit sur un compte
	 */
	@FXML
	private void doDebit() {

	}
	
	/**
	 * Permet d'enregistrer un crédit sur un compte
	 */
	@FXML
	private void doCredit() {
		
	}

	/**
	 * Permet d'enregistrer un virement entre deux comptes
	 */
	@FXML
	private void doVirement() {
		
	}

	/**
	 * Active/désactive les boutons crédit, débit et virement si le compte est cloturé ou non
	 */
	private void validateComponentState() {
		
		this.btnCredit.setDisable(false);
		this.btnDebit.setDisable(false);
		this.btnVirement.setDisable(false);
		
			this.btnCredit.setDisable(true);
			this.btnDebit.setDisable(true);
			this.btnVirement.setDisable(true);
		
	}

	private void updateInfoPrelevementCompte() {

		PairsOfValue<CompteCourant, ArrayList<PrelevementAutomatique>> prelevEtCompte;

		prelevEtCompte = this.pm.prelevementEtSoldeDunCompte();

		ArrayList<PrelevementAutomatique> listeOP;
		this.prelevementConcerne = prelevEtCompte.getLeft();
		listeOP = prelevEtCompte.getRight();

		String info;
		info = this.compteDuPrelevement.idNumCompte + "  " + this.compteDuPrelevement.solde + "  (id : " + this.compteDuPrelevement.idNumCli
				+ ")";
		this.lblInfosClient.setText(info);

		info = "Cpt. : " + this.prelevementConcerne.idNumCompte + "  "
				+ String.format(Locale.ENGLISH, "%12.02f", this.prelevementConcerne.montant) + "  /  "
				+ String.format(Locale.ENGLISH, "%8d", this.prelevementConcerne.dateRecurrente);
		this.lblInfosCompte.setText(info);

		this.olPrelevement.clear();
		for (PrelevementAutomatique pa : listeOP) {
			this.olPrelevement.add(pa);
		}

		this.validateComponentState();
	}
}
