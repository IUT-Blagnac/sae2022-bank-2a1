package application.view;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import application.DailyBankState;
import application.control.PrelevementManagement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.data.Client;
import model.data.CompteCourant;
import model.data.Prelevement;
import model.orm.AccessClient;
import model.orm.exception.DataAccessException;
import model.orm.exception.DatabaseConnexionException;
import model.orm.exception.ManagementRuleViolation;
import model.orm.exception.RowNotFoundOrTooManyRowsException;

public class PrelevementManagementController implements Initializable {

	// Etat application
	private DailyBankState dbs;
	private PrelevementManagement pm;

	// Fenêtre physique
	private Stage primaryStage;

	// Données de la fenêtre
	private CompteCourant compteDesPrelevements;
	private ObservableList<Prelevement> olPrelevement;

	// Manipulation de la fenêtre
	public void initContext(Stage _primaryStage, PrelevementManagement _pm, DailyBankState _dbstate, CompteCourant compte) {
		this.pm = _pm;
		this.primaryStage = _primaryStage;
		this.dbs = _dbstate;
		this.compteDesPrelevements = compte;
		this.configure();
	}

	private void configure() {
		String info;

		this.primaryStage.setOnCloseRequest(e -> this.closeWindow(e));

		this.olPrelevement = FXCollections.observableArrayList();
		this.lvPrelevement.setItems(this.olPrelevement);
		this.lvPrelevement.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		this.lvPrelevement.getFocusModel().focus(-1);
		this.lvPrelevement.getSelectionModel().selectedItemProperty().addListener(e -> this.validateComponentState());

		AccessClient ac = new AccessClient();
		try {
			Client c = ac.getClient(this.compteDesPrelevements.idNumCli);
			info = this.compteDesPrelevements.toString();
			this.lblInfosClient.setText(info);
		} catch (RowNotFoundOrTooManyRowsException e1) {
			e1.printStackTrace();
		} catch (DataAccessException e1) {
			e1.printStackTrace();
		} catch (DatabaseConnexionException e1) {
			e1.printStackTrace();
		}

		this.loadList();
		this.validateComponentState();
	}

	public void displayDialog() {
		this.primaryStage.showAndWait();
	}

	// Gestion du stage
	private Object closeWindow(WindowEvent e) {
		this.doCancel();
		e.consume();
		return null;
	}

	// Attributs de la scene + actions
	@FXML
	private Label lblInfosClient;
	@FXML
	private ListView<Prelevement> lvPrelevement;
	@FXML
	private Button btnModifierCompte;
	@FXML
	private Button btnSupprCompte;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
	}

	/**
	 * Permet de retourner à la page de gestion des clients
	 */
	@FXML
	private void doCancel() {
		this.primaryStage.close();
	}

	/**
	 * Permet la modification d'un compte
	 * @throws DatabaseConnexionException 
	 * @throws DataAccessException 
	 * @throws RowNotFoundOrTooManyRowsException 
	 * @throws ManagementRuleViolation 
	 */
	@FXML
	private void doModifierPrelevement() throws RowNotFoundOrTooManyRowsException, DataAccessException, DatabaseConnexionException, ManagementRuleViolation {
		int selectedIndice = this.lvPrelevement.getSelectionModel().getSelectedIndex();
		if (selectedIndice >= 0) {
			Prelevement prelev = this.olPrelevement.get(selectedIndice);
			Prelevement result = this.pm.modifierPrelevement(prelev);
			if (result != null) {
				this.loadList();
			}
		}
	}

	/**
	 * Permet la supression d'un compte si et seulement si le solde vaut 0
	 */
	@FXML
	private void doSupprimerPrelevement() throws RowNotFoundOrTooManyRowsException, DataAccessException, DatabaseConnexionException, ManagementRuleViolation {
	}

	/**
	 * Permet la création d'un compte, ouvre la fenetre de création 
	 */
	@FXML
	private void doNouveauPrelevement() {
		Prelevement prelev;
		prelev = this.pm.creerPrelevement();
		if (prelev != null) {
			this.loadList();
		}
	}

	private void loadList () {
		ArrayList<Prelevement> listePrelev;
		listePrelev = this.pm.getPrelevementsDunCompte();
		this.olPrelevement.clear();
		for (Prelevement pa : listePrelev) {
			this.olPrelevement.add(pa);
		}
	}

	/**
	 * Rend activable les différents boutons si un compte est selectionné et non cloturé
	 */
	private void validateComponentState() {
		int selectedIndice = this.lvPrelevement.getSelectionModel().getSelectedIndex();
		if (selectedIndice >= 0) {
			this.btnSupprCompte.setDisable(false);
			this.btnModifierCompte.setDisable(false);
		} else {
			this.btnSupprCompte.setDisable(true);
			this.btnModifierCompte.setDisable(true);
		}
	}
}
