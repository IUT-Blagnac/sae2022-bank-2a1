package application.control;

import java.util.ArrayList;

import application.DailyBankApp;
import application.DailyBankState;
import application.tools.AlertUtilities;
import application.tools.EditionMode;
import application.tools.StageManagement;
import application.view.ComptesManagementController;
import application.view.PrelevementManagementController;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.data.Client;
import model.data.CompteCourant;
import model.data.PrelevementAutomatique;
import model.orm.AccessClient;
import model.orm.AccessCompteCourant;
import model.orm.AccessPrelevementAutomatique;
import model.orm.exception.ApplicationException;
import model.orm.exception.DataAccessException;
import model.orm.exception.DatabaseConnexionException;
import model.orm.exception.ManagementRuleViolation;
import model.orm.exception.Order;
import model.orm.exception.RowNotFoundOrTooManyRowsException;
import model.orm.exception.Table;

public class PrelevementManagement {

	private Stage primaryStage;
	private PrelevementManagementController pmc;
	private DailyBankState dbs;
	private CompteCourant compteDesPrelevements;

	public PrelevementManagement(Stage _parentStage, DailyBankState _dbstate, CompteCourant compte) {

		this.compteDesPrelevements = compte;
		this.dbs = _dbstate;
		try {
			FXMLLoader loader = new FXMLLoader(PrelevementManagementController.class.getResource("prelevementmanagement.fxml"));
			BorderPane root = loader.load();

			Scene scene = new Scene(root, root.getPrefWidth()+50, root.getPrefHeight()+10);
			scene.getStylesheets().add(DailyBankApp.class.getResource("application.css").toExternalForm());

			this.primaryStage = new Stage();
			this.primaryStage.initModality(Modality.WINDOW_MODAL);
			this.primaryStage.initOwner(_parentStage);
			StageManagement.manageCenteringStage(_parentStage, this.primaryStage);
			this.primaryStage.setScene(scene);
			this.primaryStage.setTitle("Gestion des prélevements");
			this.primaryStage.setResizable(false);

			this.pmc = loader.getController();
			this.pmc.initContext(this.primaryStage, this, _dbstate, compte);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void doPrelevementsManagementDialog() {
		this.pmc.displayDialog();
	}

	public PrelevementAutomatique creerPrelevement() {
		PrelevementAutomatique prelev;
		PrelevementEditorPane cep = new PrelevementEditorPane(this.primaryStage, this.dbs);
		prelev = cep.doPrelevementEditorDialog(this.compteDesPrelevements, null, EditionMode.CREATION);
		if (prelev != null) {
			try {
				AccessPrelevementAutomatique apa = new AccessPrelevementAutomatique();

				apa.insertPrelevement(prelev); 

			} catch (DatabaseConnexionException e) {
				ExceptionDialog ed = new ExceptionDialog(this.primaryStage, this.dbs, e);
				ed.doExceptionDialog();
				this.primaryStage.close();
			} catch (ApplicationException ae) {
				ExceptionDialog ed = new ExceptionDialog(this.primaryStage, this.dbs, ae);
				ed.doExceptionDialog();
			}
		}
		return prelev;
	}

	public PrelevementAutomatique modifierPrelevement(PrelevementAutomatique pa) throws RowNotFoundOrTooManyRowsException, DataAccessException, DatabaseConnexionException {
		AccessCompteCourant acc = new AccessCompteCourant();
		CompteCourant cp = acc.getCompteCourant(pa.idNumCompte);
		PrelevementEditorPane cep = new PrelevementEditorPane(this.primaryStage, this.dbs);
		PrelevementAutomatique result = cep.doPrelevementEditorDialog(cp, pa,EditionMode.MODIFICATION);
		if (result != null) {
			try {
				AccessPrelevementAutomatique ac = new AccessPrelevementAutomatique();
				ac.updatePrelevement(result);
			} catch (DatabaseConnexionException e) {
				ExceptionDialog ed = new ExceptionDialog(this.primaryStage, this.dbs, e);
				ed.doExceptionDialog();
				result = null;
				this.primaryStage.close();
			} catch (ApplicationException ae) {
				ExceptionDialog ed = new ExceptionDialog(this.primaryStage, this.dbs, ae);
				ed.doExceptionDialog();
				result = null;
			}
		}
		return result;
	}

	public ArrayList<PrelevementAutomatique> getPrelevementsDunCompte() {
		ArrayList<PrelevementAutomatique> listePrelev = new ArrayList<>();

		try {
			AccessPrelevementAutomatique apa = new AccessPrelevementAutomatique();
			listePrelev = apa.getPrelevements(this.compteDesPrelevements.idNumCompte);
		} catch (DatabaseConnexionException e) {
			ExceptionDialog ed = new ExceptionDialog(this.primaryStage, this.dbs, e);
			ed.doExceptionDialog();
			this.primaryStage.close();
			listePrelev = new ArrayList<>();
		} catch (ApplicationException ae) {
			ExceptionDialog ed = new ExceptionDialog(this.primaryStage, this.dbs, ae);
			ed.doExceptionDialog();
			listePrelev = new ArrayList<>();
		}
		return listePrelev;
	}
}
