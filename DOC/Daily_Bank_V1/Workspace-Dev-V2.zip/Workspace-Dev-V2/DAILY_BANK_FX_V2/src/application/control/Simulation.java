package application.control;

import application.DailyBankApp;
import application.DailyBankState;
import application.tools.StageManagement;
import application.view.SimulationController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TabPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class Simulation {

	
	private Stage primaryStage;
	private SimulationController sc;

	/**
	 * Constructeur d'un objet Simulation et ouverture de la fenetre
	 * @param _parentStage
	 * @param _dbstate
	 */
	public Simulation (Stage _parentStage, DailyBankState _dbstate) {

		try {
			FXMLLoader loader = new FXMLLoader(SimulationController.class.getResource("simulation.fxml"));
			TabPane root = loader.load();

			Scene scene = new Scene(root);
			scene.getStylesheets().add(DailyBankApp.class.getResource("application.css").toExternalForm());

			this.primaryStage = new Stage();
			this.primaryStage.initModality(Modality.WINDOW_MODAL);
			this.primaryStage.initOwner(_parentStage);
			StageManagement.manageCenteringStage(_parentStage, this.primaryStage);
			this.primaryStage.setScene(scene);
			this.primaryStage.setTitle("Simulations");
			this.primaryStage.setResizable(false);

			this.sc = loader.getController();
			this.sc.initContext(this.primaryStage, _dbstate);
			this.primaryStage.showAndWait();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
