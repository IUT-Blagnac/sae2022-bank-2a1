package application.control;

import application.DailyBankApp;
import application.DailyBankState;
import application.tools.StageManagement;
import application.view.ListeSimulationController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ListeSimulation {

	private Stage primaryStage;
	private ListeSimulationController ls;
	
	

	public ListeSimulation (Stage _parentStage, DailyBankState _dbstate, double montantEmprunt, int dureeEmprunt, double tauxEmprunt) {

		try {
			FXMLLoader loader = new FXMLLoader(ListeSimulationController.class.getResource("listesimulation.fxml"));
			ScrollPane root = loader.load();

			Scene scene = new Scene(root, root.getPrefWidth()+70, root.getPrefHeight()+60);
			scene.getStylesheets().add(DailyBankApp.class.getResource("application.css").toExternalForm());

			this.primaryStage = new Stage();
			this.primaryStage.initModality(Modality.WINDOW_MODAL);
			this.primaryStage.initOwner(_parentStage);
			StageManagement.manageCenteringStage(_parentStage, this.primaryStage);
			this.primaryStage.setScene(scene);
			this.primaryStage.setTitle("Simulations");
			root.setVbarPolicy(ScrollBarPolicy.ALWAYS);
			
			HBox hb = new HBox ();
			
			this.ls = loader.getController();
			this.ls.initContext(this.primaryStage, _dbstate);
			
			Label [] tab = this.ls.doCalculEmprunt(montantEmprunt, tauxEmprunt / 12 / 100, dureeEmprunt);
			hb.getChildren().add(tab [0]);
			hb.getChildren().add(tab [1]);
			hb.getChildren().add(tab [2]);
			hb.getChildren().add(tab [3]);
			hb.getChildren().add(tab [4]);
			hb.getChildren().add(tab [5]);
			
			root.setContent(hb);
			
			this.primaryStage.showAndWait();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public ListeSimulation (Stage _parentStage, DailyBankState _dbstate, double montantEmprunt, int dureeEmprunt, double tauxEmprunt, double tauxAssurance) {

		try {
			FXMLLoader loader = new FXMLLoader(ListeSimulationController.class.getResource("listesimulation.fxml"));
			ScrollPane root = loader.load();

			Scene scene = new Scene(root, root.getPrefWidth()+90, root.getPrefHeight()+60);
			scene.getStylesheets().add(DailyBankApp.class.getResource("application.css").toExternalForm());

			this.primaryStage = new Stage();
			this.primaryStage.initModality(Modality.WINDOW_MODAL);
			this.primaryStage.initOwner(_parentStage);
			StageManagement.manageCenteringStage(_parentStage, this.primaryStage);
			this.primaryStage.setScene(scene);
			this.primaryStage.setTitle("Simulations");
			this.primaryStage.setResizable(false);
			root.setVbarPolicy(ScrollBarPolicy.ALWAYS);
			
			HBox hb = new HBox ();
			
			this.ls = loader.getController();
			this.ls.initContext(this.primaryStage, _dbstate);
			
			Label [] tab = this.ls.doCalculAssurance(montantEmprunt, tauxEmprunt / 12 / 100, dureeEmprunt, tauxAssurance);
			hb.getChildren().add(tab [0]);
			hb.getChildren().add(tab [1]);
			hb.getChildren().add(tab [2]);
			hb.getChildren().add(tab [3]);
			hb.getChildren().add(tab [4]);
			hb.getChildren().add(tab [5]);
			hb.getChildren().add(tab [6]);
			hb.getChildren().add(tab [7]);

			root.setContent(hb);
			
			this.primaryStage.showAndWait();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
